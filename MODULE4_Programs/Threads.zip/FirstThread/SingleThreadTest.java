package FirstThread;

public class SingleThreadTest {

	public static void main(String[] args) {
		FirstThread t1 = new FirstThread("Rabbit");
		t1.start();
	}
}
