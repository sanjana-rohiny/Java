package JOIN;

public class ConsumerThread extends Thread {

	Thread producerThread;
	DataClass dataObj;
	public ConsumerThread(Thread t, DataClass d) {
		producerThread = t;
		dataObj = d;
	}

	public void run() {
		
		try {
			System.out.println("ConsumerThread::run() ... wait on join");
			producerThread.join();			
			System.out.println("ConsumerThread::run() ... wait releases");
			
			String data = dataObj.consumeData();
			System.out.println("ConsumerThread : Consumes Data = " + data);
			System.out.println("ConsumerThread:: Thread exits...!");

		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
		
	}
}
