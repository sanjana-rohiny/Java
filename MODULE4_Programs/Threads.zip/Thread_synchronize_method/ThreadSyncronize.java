

public class ThreadSyncronize implements Runnable{
	Callme callme;
	String name;
	ThreadSyncronize(Callme target, String name) {
		this.callme = target;
		this.name = name;
	}
	
	public void run() {
		callme.printName(name);
	}
}
